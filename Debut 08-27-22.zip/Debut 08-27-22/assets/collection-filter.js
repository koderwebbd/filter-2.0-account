/*const button = document.querySelector('.CheckboxTrigger');
button.addEventListener('change', function() {  
 	form.dispatchEvent(new Event('submit', {bubbles: true})); 
})  


const form = document.querySelector(".filter-form");
form.addEventListener("submit", function (event) {
	// stop form submission
	//event.preventDefault();

  //const queryString = new URLSearchParams(new FormData(formData)).toString()

  	const formData = new FormData(form);
    const searchParams = new URLSearchParams(formData).toString();

	console.log(searchParams)
});
*/

/*Common functions*/

function getFocusableElements(container) {
  return Array.from(
    container.querySelectorAll(
      "summary, a[href], button:enabled, [tabindex]:not([tabindex^='-']), [draggable], area, input:not([type=hidden]):enabled, select:enabled, textarea:enabled, object, iframe"
    )
  );
}

const trapFocusHandlers = {};

function trapFocus(container, elementToFocus = container) {
  var elements = getFocusableElements(container);
  var first = elements[0];
  var last = elements[elements.length - 1];

  removeTrapFocus();

  trapFocusHandlers.focusin = (event) => {
    if (
      event.target !== container &&
      event.target !== last &&
      event.target !== first
    )
      return;

    document.addEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.focusout = function() {
    document.removeEventListener('keydown', trapFocusHandlers.keydown);
  };

  trapFocusHandlers.keydown = function(event) {
    if (event.code.toUpperCase() !== 'TAB') return; // If not TAB key
    // On the last focusable element and tab forward, focus the first element.
    if (event.target === last && !event.shiftKey) {
      event.preventDefault();
      first.focus();
    }

    //  On the first focusable element and tab backward, focus the last element.
    if (
      (event.target === container || event.target === first) &&
      event.shiftKey
    ) {
      event.preventDefault();
      last.focus();
    }
  };

  document.addEventListener('focusout', trapFocusHandlers.focusout);
  document.addEventListener('focusin', trapFocusHandlers.focusin);

  elementToFocus.focus();
}

function removeTrapFocus(elementToFocus = null) {
  document.removeEventListener('focusin', trapFocusHandlers.focusin);
  document.removeEventListener('focusout', trapFocusHandlers.focusout);
  document.removeEventListener('keydown', trapFocusHandlers.keydown);

  if (elementToFocus) elementToFocus.focus();
}

function onKeyUpEscape(event) {
  if (event.code.toUpperCase() !== 'ESCAPE') return;

  const openDetailsElement = event.target.closest('details[open]');
  if (!openDetailsElement) return;

  const summaryElement = openDetailsElement.querySelector('summary');
  openDetailsElement.removeAttribute('open');
  summaryElement.focus();
}
 

function debounce(fn, wait) {
    let t;
    return (...args) => {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait);
    };
}

const serializeForm = form => {
    const obj = {};
    const formData = new FormData(form);

    for (const key of formData.keys()) {
        const regex = /(?:^(properties\[))(.*?)(?:\]$)/;

        if (regex.test(key)) {
            obj.properties = obj.properties || {};
            obj.properties[regex.exec(key)[2]] = formData.get(key);
        } else {
            obj[key] = formData.get(key);
        }
    }

    return JSON.stringify(obj);
};

function fetchConfig(type = 'json') {
    return {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': `application/${type}`
        }
    };
}
 


class CollectionFiltersForm extends HTMLElement {
    constructor() {
        super();
        this.filterData = [];
        this.onActiveFilterClick = this.onActiveFilterClick.bind(this);

        this.debouncedOnSubmit = debounce((event) => {
            this.onSubmitHandler(event);
        }, 500);

        this.querySelector('form').addEventListener('input', this.debouncedOnSubmit.bind(this));
        window.addEventListener('popstate', this.onHistoryChange.bind(this));

    }



    onSubmitHandler(event) {
        event.preventDefault();
        const formData = new FormData(event.target.closest('form'));
        const searchParams = new URLSearchParams(formData).toString();
        this.renderPage(searchParams, event);
        //console.log('ready', searchParams)
    }
    onActiveFilterClick(event) {
        event.preventDefault();
        this.toggleActiveFacets();
        this.renderPage(new URL(event.currentTarget.href).searchParams.toString());
    }

    onHistoryChange(event) {
        const searchParams = event.state ? event.state.searchParams : '';
        this.renderPage(searchParams, null, false);
    }

    toggleActiveFacets(disable = true) {
        document.querySelectorAll('.js-facet-remove').forEach((element) => {
            element.classList.toggle('disabled', disable);
        });
    }

    renderPage(searchParams, event, updateURLHash = true) {
        const sections = this.getSections();
        const countContainerDesktop = document.getElementById('Collection');
        document.getElementById('Collection').querySelector('.collection_wrap').classList.add('loading');
        document.getElementById('CollectionProductCount').classList.add('loading');
        if (countContainerDesktop) {
            countContainerDesktop.classList.add('loading');
        }

        sections.forEach((section) => {
            const url = `${window.location.pathname}?section_id=${section.section}&${searchParams}`;
            const filterDataUrl = element => element.url === url;

            this.filterData.some(filterDataUrl) ?
                this.renderSectionFromCache(filterDataUrl, event) :
                this.renderSectionFromFetch(url, event);
        });

        if (updateURLHash) this.updateURLHash(searchParams);
    }

    renderSectionFromFetch(url, event) {
        fetch(url)
            .then(response => response.text())
            .then((responseText) => {
                const html = responseText;
                this.filterData = [...this.filterData, {
                    html,
                    url
                }];
                this.renderFilters(html, event);
                this.renderProductGrid(html);
                this.renderProductCount(html);
            });
    }

    renderSectionFromCache(filterDataUrl, event) {
        const html = this.filterData.find(filterDataUrl).html;
        this.renderFilters(html, event);
        this.renderProductGrid(html);
        this.renderProductCount(html);
    }

    renderProductGrid(html) {
        document.getElementById('main-collection-product-grid').innerHTML = new DOMParser().parseFromString(html, 'text/html').getElementById('main-collection-product-grid').innerHTML;
    }

    renderProductCount(html) {
        const count = new DOMParser().parseFromString(html, 'text/html').getElementById('CollectionProductCount').innerHTML
        const container = document.getElementById('CollectionProductCount');
        const containerDesktop = document.getElementById('CollectionProductCountDesktop');
        container.innerHTML = count;
        container.classList.remove('loading');
        if (containerDesktop) {
            containerDesktop.innerHTML = count;
            containerDesktop.classList.remove('loading');
        }
        document.getElementById('Collection').classList.remove('loading');
        document.querySelector('.collection_wrap').classList.remove('loading');
    }
    
    renderFilters(html, event) {
        const parsedHTML = new DOMParser().parseFromString(html, 'text/html');

        const facetDetailsElements =
            parsedHTML.querySelectorAll('.filter-form .js-filter, #MobileFilter .js-filter');
        const matchesIndex = (element) => {
            const jsFilter = event ? event.target.closest('.js-filter') : undefined;
            return jsFilter ? element.dataset.index === jsFilter.dataset.index : false;
        }
        const facetsToRender = Array.from(facetDetailsElements).filter(element => !matchesIndex(element));
        const countsToRender = Array.from(facetDetailsElements).find(matchesIndex);

        facetsToRender.forEach((element) => {
            document.querySelector(`.js-filter[data-index="${element.dataset.index}"]`).innerHTML = element.innerHTML;

            //console.log(element.innerHTML)
        });

        this.renderActiveFacets(parsedHTML);
        this.renderAdditionalElements(parsedHTML);



        if (countsToRender) this.renderCounts(countsToRender, event.target.closest('.js-filter'));
    }

    renderActiveFacets(html) {
        const activeFacetElementSelectors = ['.active-filters', '.active-filters'];

        activeFacetElementSelectors.forEach((selector) => {
            const activeFacetsElement = html.querySelector(selector);
            if (!activeFacetsElement) return;
            document.querySelector(selector).innerHTML = activeFacetsElement.innerHTML;
            //console.log(activeFacetsElement.innerHTML)
        })

        this.toggleActiveFacets(false);
    }

    renderAdditionalElements(html) {
        const mobileElementSelectors = ['.mobile-filter-button', '.mobile-facets__count', '.sorting'];

        mobileElementSelectors.forEach((selector) => {
          if (!html.querySelector(selector)) return;
          document.querySelector(selector).innerHTML = html.querySelector(selector).innerHTML;
        });

        document.getElementById('MobileFilterForm').closest('menu-drawer').bindEvents();
    }


    renderCounts(source, target) {
    const countElementSelectors = ['.count-bubble','.facets__selected'];
    countElementSelectors.forEach((selector) => {
      const targetElement = target.querySelector(selector);
      const sourceElement = source.querySelector(selector);

      if (sourceElement && targetElement) {
        target.querySelector(selector).outerHTML = source.querySelector(selector).outerHTML;
        //

        const count = target.querySelector(selector).innerHTML;
        var matches = count.replace(/\(|\)/g, '');
        var matches = matches.trim();

        console.log(matches)

        if (matches > 0) {
        	target.querySelector(selector).classList.add('display');
        }else{
        	target.querySelector(selector).classList.remove('display');
        }


      }
    });
  }


    updateURLHash(searchParams) {
        history.pushState({
            searchParams
        }, '', `${window.location.pathname}${searchParams && '?'.concat(searchParams)}`);
    }

    //Add Class
    getSections() {
        return [{
            id: 'main-collection-product-grid',
            section: document.getElementById('main-collection-product-grid').dataset.id,
        }]
    }
}
customElements.define('collection-filters', CollectionFiltersForm);


class PriceRange extends HTMLElement {
  constructor() {
    super();
    this.querySelectorAll('input')
      .forEach(element => element.addEventListener('change', this.onRangeChange.bind(this)));

    this.setMinAndMaxValues();
  }

  onRangeChange(event) {
    this.adjustToValidValues(event.currentTarget);
    this.setMinAndMaxValues();
  }

  setMinAndMaxValues() {
    const inputs = this.querySelectorAll('input');
    const minInput = inputs[0];
    const maxInput = inputs[1];
    if (maxInput.value) minInput.setAttribute('max', maxInput.value);
    if (minInput.value) maxInput.setAttribute('min', minInput.value);
    if (minInput.value === '') maxInput.setAttribute('min', 0);
    if (maxInput.value === '') minInput.setAttribute('max', maxInput.getAttribute('max'));
  }

  adjustToValidValues(input) {
    const value = Number(input.value);
    const min = Number(input.getAttribute('min'));
    const max = Number(input.getAttribute('max'));

    if (value < min) input.value = min;
    if (value > max) input.value = max;
  }
}

//customElements.define('price-range', PriceRange);

class FacetRemove extends HTMLElement {
  constructor() {
    super();
    this.querySelector('a').addEventListener('click', (event) => {
      event.preventDefault();
 
      const form = document.querySelector('collection-filters');
      form.onActiveFilterClick(event);
    });
  }
}

customElements.define('facet-remove', FacetRemove);



var lowerSlider = document.querySelector('.price_lower');
var  upperSlider = document.querySelector('.price_upper');
 
document.querySelector('#price_upper_text_value').innerHTML=theme.Currency.formatMoney(upperSlider.value * 100);
document.querySelector('#price_lower_text_value').innerHTML=theme.Currency.formatMoney(lowerSlider.value * 100);

var  lowerVal = parseFloat(lowerSlider.value);
var upperVal = parseFloat(upperSlider.value);


upperSlider.oninput = function () {
    lowerVal = parseFloat(lowerSlider.value);
    upperVal = parseFloat(upperSlider.value);

    if (upperVal < lowerVal + 10) {
        lowerSlider.value = upperVal - 10;
        if (lowerVal == lowerSlider.min) {
        upperSlider.value = 10;
        }
    }
    document.querySelector('#price_upper_text_value').innerHTML=theme.Currency.formatMoney(this.value * 100);
    document.querySelector('.update_max_price').value=this.value;


};

lowerSlider.oninput = function () {
    lowerVal = parseFloat(lowerSlider.value);
    upperVal = parseFloat(upperSlider.value);
    if (lowerVal > upperVal - 10) {
        upperSlider.value = lowerVal + 10;
        if (upperVal == upperSlider.max) {
            lowerSlider.value = parseFloat(upperSlider.max) - 10;
        }
    }
    document.querySelector('#price_lower_text_value').innerHTML=theme.Currency.formatMoney(this.value * 100);
    document.querySelector('.update_min_price').value=this.value;
};



class MenuDrawer extends HTMLElement {
  constructor() {
    super();

    this.mainDetailsToggle = this.querySelector('details');
    const summaryElements = this.querySelectorAll('summary');
    this.addAccessibilityAttributes(summaryElements);

    if (navigator.platform === 'iPhone') document.documentElement.style.setProperty('--viewport-height', `${window.innerHeight}px`);

    this.addEventListener('keyup', this.onKeyUp.bind(this));
    this.addEventListener('focusout', this.onFocusOut.bind(this));
    this.bindEvents();
  }

  bindEvents() {
    this.querySelectorAll('summary').forEach(summary => summary.addEventListener('click', this.onSummaryClick.bind(this)));
    this.querySelectorAll('button').forEach(button => button.addEventListener('click', this.onCloseButtonClick.bind(this)));
  }

  addAccessibilityAttributes(summaryElements) {
    summaryElements.forEach(element => {
      element.setAttribute('role', 'button');
      element.setAttribute('aria-expanded', false);
      element.setAttribute('aria-controls', element.nextElementSibling.id);
    });
  }

  onKeyUp(event) {
    if(event.code.toUpperCase() !== 'ESCAPE') return;

    const openDetailsElement = event.target.closest('details[open]');
    if(!openDetailsElement) return;

    openDetailsElement === this.mainDetailsToggle ? this.closeMenuDrawer(this.mainDetailsToggle.querySelector('summary')) : this.closeSubmenu(openDetailsElement);
  }

  onSummaryClick(event) {
    const summaryElement = event.currentTarget;
    const detailsElement = summaryElement.parentNode;
    const isOpen = detailsElement.hasAttribute('open');

    if (detailsElement === this.mainDetailsToggle) {
      if(isOpen) event.preventDefault();
      isOpen ? this.closeMenuDrawer(summaryElement) : this.openMenuDrawer(summaryElement);
    } else {
   		console.log(summaryElement.nextElementSibling, detailsElement)
 	  trapFocus(summaryElement.nextElementSibling);	

      setTimeout(() => {
        detailsElement.classList.add('menu-opening');
      });
    }
  }

  openMenuDrawer(summaryElement) {
    setTimeout(() => {
      this.mainDetailsToggle.classList.add('menu-opening');
    });
    summaryElement.setAttribute('aria-expanded', true);
   	trapFocus(this.mainDetailsToggle, summaryElement);
    document.body.classList.add(`overflow-hidden-${this.dataset.breakpoint}`);
  }

  closeMenuDrawer(event, elementToFocus = false) {
    if (event !== undefined) {
      this.mainDetailsToggle.classList.remove('menu-opening');
      this.mainDetailsToggle.querySelectorAll('details').forEach(details =>  {
        details.removeAttribute('open');
        details.classList.remove('menu-opening');
      });
      this.mainDetailsToggle.querySelector('summary').setAttribute('aria-expanded', false);
      document.body.classList.remove(`overflow-hidden-${this.dataset.breakpoint}`);
      removeTrapFocus(elementToFocus); 
      this.closeAnimation(this.mainDetailsToggle);
    }
  }

  onFocusOut(event) {
    setTimeout(() => {
      if (this.mainDetailsToggle.hasAttribute('open') && !this.mainDetailsToggle.contains(document.activeElement)) this.closeMenuDrawer();
    });
  }

  onCloseButtonClick(event) {
    const detailsElement = event.currentTarget.closest('details');
    this.closeSubmenu(detailsElement);
  }

  closeSubmenu(detailsElement) {
    detailsElement.classList.remove('menu-opening');
 	removeTrapFocus();
    this.closeAnimation(detailsElement);
  }

  closeAnimation(detailsElement) {
    let animationStart;

    const handleAnimation = (time) => {
      if (animationStart === undefined) {
        animationStart = time;
      }

      const elapsedTime = time - animationStart;

      if (elapsedTime < 400) {
        window.requestAnimationFrame(handleAnimation);
      } else {
        detailsElement.removeAttribute('open');
        if (detailsElement.closest('details[open]')) {
 		 	trapFocus(detailsElement.closest('details[open]'), detailsElement.querySelector('summary'));
        }
      }
    }

    window.requestAnimationFrame(handleAnimation);
  }
}

customElements.define('menu-drawer', MenuDrawer);

